<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Session;
use DB;
use Auth;
class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
       public function __construct() {
		$this->middleware('auth');
       
    }
    public function index()
    {
        
        
        $data['all_prducts']=\App\Product::get()->orderBy('product_row_id','DESC');
        return view('view-product',['data'=>$data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['products']=\App\Product::get();
        $data['messages']= DB::table('messages As To')
                               ->join('users As p', 'To.user_id', '=', 'p.id')->where('reply_status',0)
                               ->select('p.*', 'To.*')
                               ->get();
         $data['categories']= \App\Category::get();
         $data['all_prducts']=\App\Product::orderBy('product_row_id','DESC')->get();
         $data['all_orders']= DB::table('orders');
         $data['profile_info']= \Illuminate\Foundation\Auth\User::get()->where('id',Auth::user()->id)->First();
         $page_content=view('admin.pages.add-product',['data'=>$data]);
         return view('layouts.admin-layout',['data'=>$data])->with('marchantcontent',$page_content);
         
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $marchant_id=Auth::user()->id;
        $name =$request->name;
        $sd=$request->sd;
        $ld=$request->ld;
        $isfeatured=$request->isfeatured;
        $product_price= $request->product_price;
        $categoryId =$request->get('categoryid');
        $file = $request->file('product_image');
        //$file1 = $request->file('product_image');
            $destinationPath = public_path(). '/images/products/thumbs/';
            //$destination = public_path(). '/images/products/';
            $filename = $file->getClientOriginalName();
             //$filename1 = $file1->getClientOriginalName();

            $file->move($destinationPath, $filename);
            //$file1->move($destination, $filename1);

           // echo  $filename;
            
        //$image_name=$request->cte_image->getClientOriginalName();
         DB::table('products')->insert([ 'product_name' => $name,'product_price' => $product_price, 'product_image' => $filename, 'category_row_id' => $categoryId,'product_short_description' => $sd, 'product_long_description' => $ld, 'is_featured' => $isfeatured,'parent_id' => $marchant_id,'product_width' =>$request->product_width,'product_height'=>$request->product_height,'created_at' => date('Y-m-d H:i:s')]);
         return redirect('/add-product');
        
       
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
