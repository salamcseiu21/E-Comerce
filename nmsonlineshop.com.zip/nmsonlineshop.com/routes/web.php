<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PageController@index')->name('products');
Route::get('/categories', 'PageController@categories')->name('categories');
Route::get('/full-artisan-list', 'PageController@artisanlist')->name('artisanlist');
Route::get('/about-us', 'PageController@about')->name('aboutus');
Route::get('/contact-us', 'PageController@contact')->name('contuctus');
Route::get('/product-details/{id}', 'PageController@product_details');
Route::get('/merchants-details/{id}', 'PageController@artisandetails');
Route::get('/category/{id}', 'PageController@category_by_id');
Route::get('/shop/{id}', 'PageController@shop_by_marchant_id');
Route::get('/test', 'PageController@test');
Route::get('/mycart', 'CartController@mycart');
Route::get('/addToCart/{id}', 'CartController@addToCart');
Route::post('/addToCart', 'CartController@postAddToCart');
Route::post('/cartItemDelete', 'CartController@cartItemDelete');
Route::post('/cartItemDeleteAll', 'CartController@cartItemDeleteAll');
Route::post('/update-cart', 'CartController@updateCart');

Route::get('/continue-shoping', 'PageController@continueShoping');
Route::get('/product-list', 'PageController@continueShoping');
Route::get('/product-list-by-id/{id}','PageController@productlistbyCategoryId');
Route::get('/product-list-by-category/{id}','PageController@products_by_category_Id');
Route::get('/product-list-by-price/{id}','PageController@productListByPrice');
Route::get('/product-list-by-price-range/{id}','PageController@productListByPriceRange');
Route::get('/checkout', 'CheckoutController@checkout');
Route::get('/getUpazilas/{id}', 'CartController@getUpazilas');
Route::post('/confirmOrder', 'CheckoutController@confirmOrder');
Route::get('/thankyou', 'CheckoutController@thankyou');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/member-log-in', 'HomeController@index');
Route::get('/logout', 'HomeController@logout');


//-----Admin  ----------
Route::get('/log-in', 'AdminController@login');
Route::post('/admin-home', 'AdminController@postlogin');
Route::get('/admin-panel', 'AdminController@welcome');
Route::get('/admin-profile', 'AdminController@adminProfile');
Route::get('/order-details', 'AdminController@orderDetails');
Route::get('/admin-product-list','AdminController@fullProductList');
Route::get('/admin-category-list','AdminController@fullCategoryList');
Route::post('/productToDelete','AdminController@deleteProductById');
Route::get('/admin-product-list-by-id/{id}','AdminController@productlistbyCategoryId');
Route::get('/admin-product-list-by-price/{id}','AdminController@productListByPrice');
Route::get('/admin-product-list-by-price-range/{id}','AdminController@productListByPriceRange');
Route::get('/update-product/{id}','AdminController@updateProductById');
Route::post('/update-product','AdminController@postUpdateProductById');
Route::post('/categoryToDelete','AdminController@deleteCategoryById');
Route::get('/update-category/{id}','AdminController@updateCategoryById');
Route::post('/update-category','AdminController@postUpdateCategoryById');
Route::get('/messages','AdminController@sendMessage');
Route::post('/replay-message','AdminController@replayMessage');
Route::get('/send-mail','AdminController@sendMail');
Route::get('/product-in-stock','AdminController@productInStock');
//------------Super Admin---------------

Route::get('/super-log-in', 'SuperAdminController@login');
Route::post('/super-admin-home', 'SuperAdminController@postlogin');
Route::get('/super-admin', 'SuperAdminController@welcome');
Route::get('/all-orders', 'SuperAdminController@orderdetails');
Route::get('/logout', 'SuperAdminController@logout');

//-----------product categroy----------
Route::get('/add-product-category', 'ProductCategoryController@create');
Route::post('/post-add-product-category', 'ProductCategoryController@store');
//-----------product----------
Route::get('/add-product', 'ProductController@create');
Route::post('/post-add-product', 'ProductController@store');
Route::get('/get-all', 'ProductController@index');


//---------------------Profile---------------------

Route::get('/my-account', 'ProfileController@index');
Route::get('/view-profile','ProfileController@index');
Route::get('/my-profile', 'ProfileController@myProfile');
Route::get('/my-orders', 'ProfileController@myOrder');
Route::get('/change-password', 'ProfileController@changePassword');
Route::get('/send-message.user', 'ProfileController@sendMessage');
Route::post('/post-send-message.user', 'ProfileController@postSendMessage');
Route::get('/view-message.user', 'ProfileController@viewMessage');

//------------------------Marchant--------------------
Route::get('/product-list.nm','MarchantController@fullProductList');
Route::get('/add-product.nm', 'MarchantController@addProduct');
Route::post('/post-add-product.nm', 'MarchantController@postAddProduct');
Route::post('/product-To-Delete.nm','MarchantController@deleteProductById');
Route::get('/update-product.nm/{id}','MarchantController@updateProductById');
Route::post('/update-product.nm','MarchantController@postUpdateProductById');
Route::get('/order-details.nm','MarchantController@orderDetails');
Route::get('/add-sub-category.nm','MarchantController@addProductSubCategory');
Route::post('/post-add-sub-category.nm', 'MarchantController@postAddProductSubCategory');
Route::get('/sub-category-list.nm','MarchantController@fullSubCategoryList');


