<?php $__env->startSection('content-section'); ?>
<!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i>Pending Orders</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                 
                    <th>Order No</th>
                    <th>Total Price</th>
                   <th>Order Date</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Order No</th>
                    <th>Total Price</th>
                   <th>Order Date</th>
                </tr>
              </tfoot>
              <tbody>
                  
                  <?php $__currentLoopData = $data['all_orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
              <td><?php echo e($row->order_id); ?></td>
                       
                  <td><?php echo e($row->product_total_price); ?></td>
                 <td><?php echo e($row->created_at); ?></td>
                </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
              </tbody>
            </table>
          </div>
        </div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('superadmin.pages.super-admin-home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>