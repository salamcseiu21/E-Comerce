<?php $__env->startSection('marchantcontent'); ?>

 <div class="box">
            <div class="box-header">
                <h3 class="box-title text-center"><strong>Product List</strong></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Name</th>
                  <th>SKU</th>
                  <th>Qty</th>
                  <th>Price</th>
                  <th>Total Price</th>
                  <th>Date</th>
                </tr>
                </thead>
                <tbody>
                
                    <?php $__currentLoopData = $data['all_orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                    <tr>
                   <td>Name</td>
                   <td><?php echo e($row->product_sku); ?></td>
                   <td><?php echo e($row->qty); ?></td>
                    <td><?php echo e($row->qty); ?></td>
                     <td><?php echo e($row->qty); ?></td>
                      <td><?php echo e($row->order_date); ?></td>
                        </tr>
				   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    
               
              
                </tbody>
                <tfoot>
                 <tr>
                  <th>Name</th>
                  <th>SKU</th>
                  <th>Qty</th>
                  <th>Price</th>
                   <th>Total Price</th>
                  <th>Date</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>

          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
}
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.marchant-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>