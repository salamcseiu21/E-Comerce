 

<?php $__env->startSection('content-artisan'); ?>

    <div class="row">
            <div class="col-sm-12">
                <div id="slider-carousel-artisan" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="item active" style="padding:30px">
                            <div class="col-sm-12">


                <div class="row">
                                    <?php $__currentLoopData = $data3['artisans']->slice(0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3" style="margin: 0;padding:5px;">
                                   
                                             <div class="panel-body text-center" style="background-color: white">

                                                <a href="<?php echo e(asset("/")); ?>merchants-details/<?php echo e($row->merchant_id); ?>" title=" <?php echo e($row->merchant_name); ?>"> 

                                                    <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($row->merchant_image); ?>"  style="width:200px;height: 220px;" alt="Image">
                                                </a><br>
                                                <div class="row" style="margin-top:30px">
                                                      <h2><?php echo e($row->merchant_name); ?></h2>  
                                                   <a style="text-transform: uppercase;font-weight: bold;" href="<?php echo e(asset("/")); ?>merchants-details/<?php echo e($row->merchant_id); ?>">See story</a>
                                                </div>
                                                
                                               
                                            </div>
                                        
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>




                            </div>
                        </div>
                     
                        <div class="item" style="padding:30px">
                              <div class="col-sm-12">


                <div class="row">
                        
                                    <?php $__currentLoopData = $data3['artisans']->take(-4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-3" style="margin: 0;padding:5px;">
                                        

                                        <div class="panel-body text-center" style="background-color: white">

                                                <a href="<?php echo e(asset("/")); ?>merchants-details/<?php echo e($row->merchant_id); ?>" title=" <?php echo e($row->merchant_name); ?>"> 

                                                    <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($row->merchant_image); ?>"  style="width:200px;height: 220px;" alt="Image">
                                                </a><br>
                                                <div class="row" style="margin-top:30px">
                                                      <h2><?php echo e($row->merchant_name); ?></h2>  
                                                   <a style="text-transform: uppercase;font-weight: bold;" href="<?php echo e(asset("/")); ?>merchants-details/<?php echo e($row->merchant_id); ?>">See story</a>
                                                </div>
                                                
                                               
                                            </div>

                                     
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </div>
                        </div>

                    </div>

                    <a href="#slider-carousel-artisan" class="left control-carousel hidden-xs" data-slide="prev">
                         <i class="fa fa-arrow-circle-o-left" style="font-size:30px"></i>
                    </a>
                    <a href="#slider-carousel-artisan" class="right control-carousel hidden-xs" data-slide="next">
                         <i class="fa fa-arrow-circle-o-right" style="font-size:30px"></i>
                    </a>
                </div>

            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>