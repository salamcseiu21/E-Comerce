<?php $__env->startSection('maincontent'); ?>
  <div class="row cart-content" style="padding: 0 14px">    
			<!-- product details -->   
			<div id="cart-container">
				
				 <?php echo csrf_field(); ?> <!-- this is a helper method =input typr=hidddden, name="". value=""-->
					<table class="table table-bordered table-responsive">
                                           
						<thead>
                                                <caption class="text-center"><h3 style="margin: 0;padding: 0">Order List</h3></caption>
							<tr>
                                                       <th>Order No</th>
							<th>Order Details</th>
							<th>Customer Info</th>
                                                        <th>Order Date</th>
                                                         <th>Shipping Address</th>
                                                        <th>Payment Method</th>
							</tr>
						</thead>
						<tbody>	

											
						<?php $__currentLoopData = $data['all_orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                               <?php $paymentId=json_decode($order->payment_method)->payment_id ?>
						 <tr>
                                                  <td>NMSORD# <?php echo e($order->order_id); ?></td>
						  <td>
						  	
						  	<table class="table">
						  		<thead>
						  			<tr>
						  			<th>Name</th>
						  			<th>SKU</th>
						  			<th>Qty</th>
						  		</tr>
						  		</thead>
						  		<tbody>
						  			<?php $__currentLoopData = json_decode($order->order_details); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  			<tr>
						  				<td><?php echo e($od->product_name); ?></td>
						  				<td><?php echo e($od->product_sku); ?></td>
						  				<td><?php echo e($od->product_qty); ?></td>
						  			</tr>
						  			
						       
						  	   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  	  
						  		</tbody>
						  		<tfoot>
						  			<tr>
						  				<td colspan="2">Total</td>
						  				<td> <?php echo e($order->product_total_price); ?></td>
						  			</tr>
						  		</tfoot>
						  		
						  	</table>	
						    </td>
						  <td><?php echo e($order->name); ?><br>
						  
						  	<?php echo e($order->email); ?>


						  </td>
						  <td><?php echo e($order->created_at); ?></td>
						   <td>
						   	<?php echo e(json_decode($order->shiping_address)->name); ?><br>
						   	<?php echo e(json_decode($order->shiping_address)->mobile); ?><br>
						   	 	<?php echo e(json_decode($order->shiping_address)->address); ?>

						   </td>
						   <td>
                                                      
                                                      <?php if($paymentId==1): ?>
                                                      <strong>Method Name:</strong> <?php echo e(json_decode($order->payment_method)->payment_method); ?><br>
                                                      <strong>Tnx ID:</strong>    <?php echo e(json_decode($order->payment_method)->txr_id); ?><br>
                                                       <?php elseif($paymentId==2): ?>
                                                      <strong>Method Name:</strong> <?php echo e(json_decode($order->payment_method)->payment_method); ?><br>
                                                        <?php elseif($paymentId==3): ?>
                                                        <strong>Method Name:</strong>   <?php echo e(json_decode($order->payment_method)->payment_method); ?><br>
                                                        <strong>Card Name :</strong>  <?php echo e(json_decode($order->payment_method)->card_name); ?><br>
                                                        <strong>Card No :</strong>  <?php echo e(json_decode($order->payment_method)->card_no); ?><br>
                                                        <strong>CW :</strong>  <?php echo e(json_decode($order->payment_method)->cw); ?><br>
                                                        <strong>Exp Date:</strong>    <?php echo e(json_decode($order->payment_method)->exp_month); ?>-<?php echo e(json_decode($order->payment_method)->exp_year); ?><br>
                                                      <?php endif; ?>
                                                   </td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
					  </tbody>
					</table>
			</div>
		 <!-- End Normal Product -->           
		</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>