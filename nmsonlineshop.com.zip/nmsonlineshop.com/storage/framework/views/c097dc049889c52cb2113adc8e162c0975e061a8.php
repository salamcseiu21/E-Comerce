<?php $__env->startSection('merchant-section'); ?>
 <div class="container">
    
      <div class="row">
           
     <div class="col-md-5" style="padding: 0px;margin: 0;">
        
         <div class="panel-body" style="font-weight: bold;">
             <div class="row">
                 <div class="col-sm-3">
                       <a href="#" title="<?php echo e($data["artisan"]->shop_name); ?>"> <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($data["artisan"]->shop_image); ?>"  style="width:100px;height: 110px;" alt="Image" /></a>
                 </div>
                 <div class="col-sm-9" style="margin: 0;padding:0;">
                     &nbsp; <p style="text-transform: uppercase;margin: 0;padding:0;"><?php echo e($data["artisan"]->shop_name); ?></p>
                      <a href="#" class="btn"><?php echo e($data["artisan"]->shop_category); ?></a>
                 </div>
             </div>
          
           
        </div>
         
     </div>
       <div class="col-md-7">
           
        
      </div> 
        
         </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('single-product-details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>