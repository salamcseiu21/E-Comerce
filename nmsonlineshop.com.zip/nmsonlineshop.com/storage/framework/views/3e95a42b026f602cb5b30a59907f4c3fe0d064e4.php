 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section style="padding:30px">
    <h2 class="title text-center" style="margin: 0;">NMS Artisans</h2>
</section>
 <div class="container">    

       
         <div class="row">
      <?php $__currentLoopData = $artisan['artisans']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-3" style="margin: 0;padding:5px;">
                                        

                                        <div class="panel-body text-center" style="background-color: white">

                                                <a href="<?php echo e(asset("/")); ?>merchants-details/<?php echo e($row->merchant_id); ?>" title=" <?php echo e($row->merchant_name); ?>"> 

                                                    <img src="<?php echo e(asset("/public/images/merchants")); ?>/<?php echo e($row->merchant_image); ?>"  style="width:200px;height: 220px;" alt="Image">
                                                </a><br>
                                                <div class="row" style="margin-top:30px">
                                                      <h2><?php echo e($row->merchant_name); ?></h2>  
                                                   <a style="text-transform: uppercase;font-weight: bold;" href="<?php echo e($row->merchant_website_url); ?>">See story</a>
                                                </div>
                                                
                                               
                                            </div>

                                     
                                    </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  

         </div>
 </div>

  <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

