
<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br>
<section>
   
  <div class="row">
     <div class="container">   
      <?php $__currentLoopData = $data['all_products_by_category_id']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="col-sm-3" style="margin: 0;padding: 0;">

                    <div class="product-image-wrapper" style="background-color: white">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title="<?php echo e($row->product_name); ?>"> 

                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:170px;height: 200px;" alt="Image">
                                </a>
                                <h2 style="margin:0;padding: 7px"><?php echo e($row->product_price); ?> Tk</h2>
                                <p style="margin:0;padding-bottom: 7px"><?php echo e($row->product_name); ?></p>

                            </div>

                        </div>
                    </div>


                </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </div>
</div>
    </section>
<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>