<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br>
<section>

    <div class="container">  
        <div class="row" style="padding:0">
            <div class="col-sm-3" style="margin: 0;padding-left: 13px;">
                <form action="<?php echo e(url('/')); ?>/confirm-order" method="post">
                    <?php echo e(csrf_field()); ?>


                    <select class="form-control" id="catergory_dropdown">
                        <option value="0">All</option>
                        <?php $__currentLoopData = $data1['all_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($row->category_row_id); ?>"><?php echo e($row->category_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select><br>


                </form>
            </div>
            <div class="col-sm-3">
                <form action="<?php echo e(url('/')); ?>/confirm-order" method="post">
                    <?php echo e(csrf_field()); ?>


                    <select class="form-control" id="short_by_price">
                        <option value="0">Short By</option>
                        <option value="1">Price Low to High</option>
                        <option value="2">Price  High to Low</option>
                    </select><br>

                </form>
            </div>
            <div class="col-sm-3">
                <form action="<?php echo e(url('/')); ?>/confirm-order" method="post">
                    <?php echo e(csrf_field()); ?>


                    <select class="form-control" id="short_by_price_range">
                        
                         <option value="0">Price Range</option>
                         <option value="1">100-500</option>
                        <option value="2">500-1000</option>
                        <option value="3">1000-10000</option>
                        <option value="4">10000-20000</option>
                         <option value="5">20000-Up</option>
                    </select><br>

                </form>
            </div>
            <div class="col-sm-3 text-center">

                TOTAL  <?php echo e($data['all_products']->count()); ?>+ ITEMS

            </div>
        </div>
        <div class="row">

            <div class="col-sm-3">
              <?php echo $__env->make('left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-sm-9" id="full_product_list">

                <?php $__currentLoopData = $data['all_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3" style="margin: 0;padding:5px;">

                    <div class="product-image-wrapper" style="border-style:solid;border-width: 1px;border-color: pink;background-color: white">
                        <div class="single-products">
                            <div class="productinfo text-center">
                                <a href="<?php echo e(asset("/")); ?>product-details/<?php echo e($row->product_row_id); ?>" title="<?php echo e($row->product_name); ?>"> 

                                    <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($row->product_image); ?>"  style="width:170px;height: 200px;" alt="Image">
                                </a>
                                <h2 style="margin:0;padding: 7px"><?php echo e($row->product_price); ?> Tk</h2>
                                <p style="margin:0;padding-bottom: 7px"><?php echo e($row->product_name); ?></p>

                            </div>

                        </div>
                    </div>


                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">

$('#catergory_dropdown').change(function () {
    var categoryId = $(this).val();

    $('#full_product_list').empty();

    //call ajax send this selected_district_id
    $.ajax({
        url: "<?php echo e(url('product-list-by-id/')); ?>" + '/' + categoryId,
        type: "GET",
        dataType: "html",
        success: function (data) {
            $("#full_product_list").append(data)
        }
    });

});
$('#short_by_price').change(function () {
    var sortVal = $(this).val();

    $('#full_product_list').empty();

    //call ajax send this selected_district_id
    $.ajax({
        url: "<?php echo e(url('product-list-by-price/')); ?>" + '/' + sortVal,
        type: "GET",
        dataType: "html",
        success: function (data) {
            $("#full_product_list").append(data)
        }
    });

});

$('#short_by_price_range').change(function () {
    var sortVal = $(this).val();

    $('#full_product_list').empty();

    //call ajax send this selected_district_id
    $.ajax({
        url: "<?php echo e(url('product-list-by-price-range/')); ?>" + '/' + sortVal,
        type: "GET",
        dataType: "html",
        success: function (data) {
            $("#full_product_list").append(data)
        }
    });

});

</script>

<?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>