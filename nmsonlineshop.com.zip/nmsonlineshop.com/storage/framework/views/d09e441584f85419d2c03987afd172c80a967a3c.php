 <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">    
  <div class="row" style="margin: 0;padding:0;">
    
     <div class="col-sm-4">
      <div class="panel panel-primary">
        <div class="panel-heading"><?php echo e($data["product_detals_by_Id"]->product_name); ?></div>
        <div class="panel-body">
           
            <img src="<?php echo e(asset("/public/images/products/thumbs")); ?>/<?php echo e($data["product_detals_by_Id"]->product_image); ?>"  style="width:250px;height: 250px;" alt="Image"
            </div>
        <div class="panel-footer"> Price: <?php echo e($data["product_detals_by_Id"]->product_price); ?></div>
      </div>
     </div>

  </div>
</div>
 
   <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

